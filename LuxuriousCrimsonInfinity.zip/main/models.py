from django.db import models

# Create your models here.
#need both user and item classes
#each item will have its user in a foreign key